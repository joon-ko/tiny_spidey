from .spidey import *

print("what the fuck is importing")